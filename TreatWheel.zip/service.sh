MODPATH="${0%/*}"

$MODPATH/cmd/treat-wheel